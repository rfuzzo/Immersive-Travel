local defaultConfig = {
    mod = "Immersive Vehicles",
    id = "IMV",
    version = 1.0,
    author = "rfuzzo",
    -- configs
    logLevel = "DEBUG",
}

return mwse.loadConfig("ImmersiveVehicles", defaultConfig)
