---@type ServiceData
local this = {
  class = "Gondolier",
  mount = "a_gondola_01",
  ground_offset = 0,
  override_npc = {
    "Blatta Hateria"
  },
  guide = {
    "devas irano",
    "aren maren",
    "talsi uvayn",
    "dalse adren",
    "fendryn drelvi"
  }
}

return this
